    const userInvoice = {
      userName: "Pravin Kumar",
      roomNumber: "101",
      checkInDate: "10-Aug-2024",
      checkOutDate: "15-Aug-2024",
      roomCharges: 4000,
      foodCharges: 1200,
      laundryCharges: 500,
      additionalServices: 800
    };





    window.onload = function () {
     const storedInvoice = userInvoice;
      if (storedInvoice) {
        document.getElementById('userName').textContent = storedInvoice.userName;
        document.getElementById('roomNumber').textContent = storedInvoice.roomNumber;
        document.getElementById('checkInDate').textContent = storedInvoice.checkInDate;
        document.getElementById('checkOutDate').textContent = storedInvoice.checkOutDate;
        document.getElementById('roomCharges').textContent = storedInvoice.roomCharges;
        document.getElementById('foodCharges').textContent = storedInvoice.foodCharges;
        document.getElementById('laundryCharges').textContent = storedInvoice.laundryCharges;
        document.getElementById('additionalServices').textContent = storedInvoice.additionalServices;

        const totalAmount = storedInvoice.roomCharges + storedInvoice.foodCharges +
          storedInvoice.laundryCharges + storedInvoice.additionalServices;
        document.getElementById('total-amount').textContent = `Total Amount: ₹${totalAmount}`;
      }
    };

    function payNow() {
      alert("Payment Successful! Thank you for your stay.");
    }