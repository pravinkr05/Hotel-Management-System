package com.Controller;

import java.io.IOException;
import java.sql.Date;
import java.text.SimpleDateFormat;
import java.util.List;
import java.util.Random;
import java.util.concurrent.TimeUnit;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.Model.Reservation;
import com.Operation.HMSOperation;



@WebServlet("/reservationServelet")
public class reservationServelet extends HttpServlet {
	private static final long serialVersionUID = 1L;
  
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		String userid= (String) request.getSession().getAttribute("userId");
		List<Reservation> ll = HMSOperation.fetchSpecificCustomerReservation(userid);
		if(!ll.isEmpty()) {
		    request.setAttribute("reservationList", ll);
		
		    RequestDispatcher dispatcher = request.getRequestDispatcher("BookingList/bookingList.jsp");
			dispatcher.forward(request,  response);
		    return;
		}else {
			   RequestDispatcher dispatcher = request.getRequestDispatcher("BookingList/bookingList.jsp");
				dispatcher.forward(request,  response);
				
			//response.getWriter().println("No list is available");
			return;
		}
		
		
		
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		Random random = new Random();
	    int resId = 10000 + random.nextInt(90000); 
	    int roomn = 100 + random.nextInt(900); 
	    String userId = request.getParameter("userId");
	      String checkIn = request.getParameter("checkInDate");
	      String checkOut = request.getParameter("checkOutDate");
	      String roomP = request.getParameter("roomPreferences");
	      String name = request.getParameter("name");
	      String contact = request.getParameter("contact");
	      String status = "pending";
	      String pay_status = "pending";
	      int bill=100;
	      int billperday = 300;
	      int totalBill = 0;
	      int foodBill = 200;
	      int serviceCharge=50;
	      int additionalCharge=100;
	      

	      try {
	          // Define the date format according to the input format (e.g., "yyyy-MM-dd")
	          SimpleDateFormat sdf = new SimpleDateFormat("mm-dd-yyyy");

	          // Parse the check-in and check-out dates
	          Date checkInDate = (Date) sdf.parse(checkIn);
	          Date checkOutDate = (Date) sdf.parse(checkOut);

	          // Calculate the difference in milliseconds
	          long diffInMillies = Math.abs(checkOutDate.getTime() - checkInDate.getTime());

	          // Convert the difference into days
	          long daysSpent = TimeUnit.DAYS.convert(diffInMillies, TimeUnit.MILLISECONDS);

	          // Calculate the total bill
	          totalBill = (int) daysSpent * billperday;
	          foodBill = (int) daysSpent * foodBill;

	      } catch (Exception e) {
	          e.printStackTrace();
	      }

	      // Now, totalBill contains the total amount based on the days spent
	      System.out.println("Total Bill: " + totalBill);

	  Reservation rs = new Reservation(resId,userId,checkIn,checkOut, roomP,name,contact,
			  status,pay_status,totalBill,foodBill,serviceCharge,additionalCharge,roomn);
	  
	 
	  int a = HMSOperation.userReservation(rs);
	  
	  if(a>0) {
		  System.out.println("Inserted");
		  List<Reservation> ll = HMSOperation.fetchSpecificCustomerReservation(userId);
			if(ll!=null) {
			    request.setAttribute("reservationList", ll);
			    doGet(request,response);
//			    RequestDispatcher dispatcher = request.getRequestDispatcher("BookingList/bookingList.jsp");
//				dispatcher.forward(request,  response);
			    return;
			}else {
				response.getWriter().println("No list is available");
				return;
			}
	  }else {
		  response.getWriter().println("not Inserted");
	  }
	}

}
