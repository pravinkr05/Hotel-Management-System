// Sample reservations data
const reservations = [
    { id: 1, name: 'Batman', roomType: 'Suite', status: 'Pending' },
    { id: 2, name: 'Shaktiman', roomType: 'Single Room', status: 'Pending' },
    { id: 3, name: 'Mr. Potter', roomType: 'Double Room', status: 'Pending' }
];

document.addEventListener('DOMContentLoaded', function() {
    const reservationList = document.getElementById('reservationList');
    const checkInSection = document.getElementById('checkInSection');
    const userNameSpan = document.getElementById('userName');
    const roomTypeSpan = document.getElementById('roomType');

    function renderReservations() {
        reservationList.innerHTML = ''; // Clear existing content
        reservations.forEach(reservation => {
            const reservationDiv = document.createElement('div');
            reservationDiv.className = 'reservationItem';
            reservationDiv.innerHTML = `
                <p><strong>Name:</strong> ${reservation.name}</p>
                <p><strong>Room Type:</strong> ${reservation.roomType}</p>
                <p><strong>Status:</strong> ${reservation.status}</p>
                <label for="status-${reservation.id}">Action:</label>
                <select id="status-${reservation.id}">
                    <option value="" disabled selected>Select action</option>
                    <option value="approve">Approve</option>
                    <option value="reject">Reject</option>
                </select>
                <button onclick="handleAction(${reservation.id})">Submit</button>
            `;
            reservationList.appendChild(reservationDiv);
        });
    }

    renderReservations();
});


function handleAction(id) {
    const selectElement = document.getElementById(`status-${id}`);
    const action = selectElement.value;
    const reservation = reservations.find(res => res.id === id);

    if (action === 'approve') {
        reservation.status = 'Approved';
        document.getElementById('userName').textContent = reservation.name;
        document.getElementById('roomType').textContent = reservation.roomType;
        document.getElementById('checkInSection').classList.remove('hidden');
        alert("User: "+reservation.name+" Room Type: "+ reservation.roomType + " approved");
    } else if (action === 'reject') {
        reservation.status = 'Rejected';
        alert("User: "+reservation.name+" Room Type: "+ reservation.roomType + " rejected");
    }
    renderReservations(); 
}


function renderReservations() {
    const reservationList = document.getElementById('reservationList');
    reservationList.innerHTML = ''; // Clear existing content
    reservations.forEach(reservation => {
        const reservationDiv = document.createElement('div');
        reservationDiv.className = 'reservationItem';
        reservationDiv.innerHTML = `
            <p><strong>Name:</strong> ${reservation.name}</p>
            <p><strong>Room Type:</strong> ${reservation.roomType}</p>
            <p><strong>Status:</strong> ${reservation.status}</p>
            <label for="status-${reservation.id}">Action:</label>
            <select id="status-${reservation.id}">
                <option value="" disabled selected>Select action</option>
                <option value="approve">Approve</option>
                <option value="reject">Reject</option>
            </select>
            <button onclick="handleAction(${reservation.id})">Submit</button>
        `;
        reservationList.appendChild(reservationDiv);
    });
}
