package com.Operation;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.Model.Reservation;
import com.Model.UserData;

public class HMSOperation {
	  private static String adminId="tcsilp";
	    private static String adminPswd = "123";
	    
	  Connection con = null;
	  private static Statement st = null;
   
   
	public HMSOperation(){
		
	}
	public static int updateReservationPaymentStatus(int reservationId) {
		  int result = -1;
	        try (Connection conn = DatabaseConnection.getConnection()) {
	            String query = "UPDATE Reservation SET payment_status = ? WHERE ReservationId = ?";
	            PreparedStatement ps = conn.prepareStatement(query);
	            ps.setString(1, "Success");
	            ps.setInt(2, reservationId);
	            result = ps.executeUpdate();

				DriverManager.getConnection("jdbc:derby:D:\\Users\\2725297\\MyDB;shutdown=true");
	        } catch (Exception e) {
	            e.printStackTrace();
	        }
	        
	        return result;
	  }
	public static List<Reservation> fetchSpecificCustomerBill(int rid) {
		List<Reservation> bill=new ArrayList<>();
		  try {
	             Connection con = DatabaseConnection.getConnection();
	        
	             String q2 = "SELECT * FROM Reservation";
	        	 st = con.createStatement();
	            ResultSet rs = null;
	            rs = st.executeQuery(q2);
	            
	            while (rs.next()) {
	            	if(rs.getInt(1)==(rid)) {
		            	int a = rs.getInt(1);
		            	String b = rs.getString(3);
		            	String c = rs.getString(4);
		            	String d = rs.getString(5);
		            	String e = rs.getString(6);
		            	String f = rs.getString(7);
		            	String g = rs.getString(8);
		            	String h = rs.getString(9);
		            	int i = rs.getInt(10);
		            	int j = rs.getInt(11);
		            	int k = rs.getInt(12);
		            	int l = rs.getInt(13);
		            	int m = rs.getInt(14);
		            
		            	Reservation r = new Reservation(a,rs.getString(2),b,c,d,e,f,g,h,i,j,k,l,m);
		            	bill.add(r);
		            	}
	            }
				   
	           
	        	con.close();

				DriverManager.getConnection("jdbc:derby:D:\\Users\\2725297\\MyDB;shutdown=true");
				} catch (SQLException e) {
				
					e.printStackTrace();
				}
	        return bill;
		
		
	}
	
	public static int updateReservationStatus(int reservationId, String status) {
		  int result = -1;
	        try (Connection conn = DatabaseConnection.getConnection()) {
	            String query = "UPDATE Reservation SET status = ? WHERE ReservationId = ?";
	            PreparedStatement ps = conn.prepareStatement(query);
	            ps.setString(1, status);
	            ps.setInt(2, reservationId);
	            result = ps.executeUpdate();

				DriverManager.getConnection("jdbc:derby:D:\\Users\\2725297\\MyDB;shutdown=true");
	        } catch (Exception e) {
	            e.printStackTrace();
	        }
	        
	        return result;
	  }
	
	
	public static List<Reservation> getAllReservations() {
		  
        List<Reservation> reservations = new ArrayList<>();
        
        try {
             Connection con = DatabaseConnection.getConnection();
        
             String q2 = "SELECT * FROM Reservation";
        	 st = con.createStatement();
            ResultSet rs = null;
            rs = st.executeQuery(q2);
            
            while (rs.next()) {
                Reservation reservation = new Reservation();
                reservation.setResId(rs.getInt(1));
                reservation.setName(rs.getString(5));
                reservation.setRoomP(rs.getString(4));
                reservation.setStatus(rs.getString(8));
                reservation.setPayment(rs.getString(9));
                reservations.add(reservation);
            }
			   
           
        	con.close();

			DriverManager.getConnection("jdbc:derby:D:\\Users\\2725297\\MyDB;shutdown=true");
			} catch (SQLException e) {
			
				e.printStackTrace();
			}
        
	return reservations;
     
    }
  

	
	public static int userReservation(Reservation rs) {

		int temp=-1;
		
        
  
        	try {
        		

        	Connection con = DatabaseConnection.getConnection();
            st = con.createStatement();
  
            
        String q1 = "INSERT INTO Reservation VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)";

        PreparedStatement pst = con.prepareStatement(q1);
        pst.setInt(1, rs.getResId());
        pst.setString(2, rs.getUserId());
        pst.setString(3, rs.getCheckIn());
        pst.setString(4, rs.getCheckOut());
        pst.setString(5, rs.getRoomP());
        pst.setString(6, rs.getName());
        pst.setString(7, rs.getContact());
        pst.setString(8, rs.getStatus());
        pst.setString(9, rs.getPayment());
        pst.setInt(10, rs.getBill());
        pst.setInt(11, rs.getFoodBill());
        pst.setInt(12, rs.getServiceCharge());
        pst.setInt(13, rs.getAdditionalCharge());
        pst.setInt(14, rs.getRoomno());
        temp = pst.executeUpdate();
        
        if(temp>0)
    	{System.out.println("Successfully Reservation inserted!");
    	}
      
        if (con != null) con.close();
        
			DriverManager.getConnection("jdbc:derby:D:\\Users\\2725297\\MyDB;shutdown=true");
        	} catch (SQLException e) {
				e.printStackTrace();
			}    
   

    return temp;    
	}
	
	public static List<Reservation> fetchSpecificCustomerReservation(String userId){
		 List<Reservation> res = null;
		
		 try {
	          

			 Connection con = DatabaseConnection.getConnection();

	        	 String q2 = "SELECT * FROM Reservation";
	        	 st = con.createStatement();
	            ResultSet rs = null;
	            rs = st.executeQuery(q2);
	           
	             res = new ArrayList<>();
	            while(rs.next()){
	            	if(rs.getString(2).equals(userId)) {
	            	int a = rs.getInt(1);
	            	String b = rs.getString(3);
	            	String c = rs.getString(4);
	            	String d = rs.getString(5);
	            	String e = rs.getString(6);
	            	String f = rs.getString(7);
	            	String g = rs.getString(8);
	            	String h = rs.getString(9);
	            
	            	Reservation r = new Reservation(a,userId,b,c,d,e,f,g,h);
	            	res.add(r);
	            	}
				   
	             }
	        	con.close();
				DriverManager.getConnection("jdbc:derby:D:\\Users\\2725297\\MyDB;shutdown=true");
	        } catch ( SQLException e) {
	            // TODO Auto-generated catch block
	        	e.printStackTrace();
	        }
		
		return res;
	}
	
	public static boolean adminLoggedIn(String userId, String pswd) {

		  boolean check = false;

		if(userId.equals(adminId)   && pswd.equals(adminPswd)) {
			    	 check = true;
			  }
  
		return check;
	}
	
	
	public static boolean loggedIn(String userId, String pswd) {
		
		  boolean check = false;
      try {
        
    	  Connection con = DatabaseConnection.getConnection();
          
   
      	 String q2 = "SELECT * FROM UserData";
      	 st = con.createStatement();
          ResultSet rs = null;
          rs = st.executeQuery(q2);
         
        
          while(rs.next()){
          	
			     if(userId.equalsIgnoreCase(rs.getString(1))   && pswd.equalsIgnoreCase(rs.getString(6))) {
			    	 check = true;
			       
			     }
           }
      	con.close();
			DriverManager.getConnection("jdbc:derby:D:\\Users\\2725297\\MyDB;shutdown=true");
      } catch ( SQLException e) {
      	e.printStackTrace();
      }
		return check;
	}
     
	
	public static int registerData(UserData user) {
	      int temp=-1;
	
	            	try {
	            		

	            	   Connection con = DatabaseConnection.getConnection();
					

						System.out.println("Insert");
						String q1 = "INSERT INTO UserData (UserID, Username, Phno, Email, Address, Pswd) VALUES (?,?,?,?,?,?)";

						PreparedStatement pst = con.prepareStatement(q1);
						pst.setString(1, user.getUserID()); 
						pst.setString(2, user.getUsername());
						pst.setString(3, user.getPhno());
						pst.setString(4, user.getEmail());
						pst.setString(5, user.getAddress());
						pst.setString(6, user.getPswd());

					    temp = pst.executeUpdate();

						if(temp > 0) {
						    System.out.println("Successfully inserted!");
						}

						if (con != null) con.close();
						
					DriverManager.getConnection("jdbc:derby:D:\\Users\\2725297\\MyDB;shutdown=true");
	            	} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}    
	       
		
	        return temp;    
	   
	}
	
	
	
	
        
	
	
	
	  

	 
	
}
