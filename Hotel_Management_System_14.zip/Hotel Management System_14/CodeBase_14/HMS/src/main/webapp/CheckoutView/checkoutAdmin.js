function checkout() {
    // Show the notification pop-up when checkout is done
    const popup = document.getElementById("popup");
    popup.classList.remove("hidden");
}

function closePopup() {
    // Close the pop-up
    const popup = document.getElementById("popup");
    popup.classList.add("hidden");
}