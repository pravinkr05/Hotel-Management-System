
window.onload = function() {
    const username = "John Doe";  // Example username
    document.getElementById('welcomeMessage').textContent = `Welcome, ${username}!`;
};

// Responsive Menu Toggle
document.querySelector('.menu-toggle').addEventListener('click', () => {
    document.querySelector('.nav-links').classList.toggle('active');
});

// Search Functionality
document.getElementById('searchBtn').addEventListener('click', () => {
    const location = document.getElementById('locationSearch').value;
    alert(`Searching hotels in ${location}`);
});

// Logout Functionality
document.getElementById('logout-link').addEventListener('click', function() {
    alert('Logged out successfully!');
    window.location.href = 'login.html';
});