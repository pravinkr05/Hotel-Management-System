document.addEventListener('DOMContentLoaded', () => {
    const searchBar = document.getElementById('searchBar');
    const itemsPerPageSelect = document.getElementById('itemsPerPage');
    const prevButton = document.getElementById('prevButton');
    const nextButton = document.getElementById('nextButton');
    const tableBody = document.querySelector('#historyTable tbody');
    const detailView = document.getElementById('detailView');
    const detailData = document.getElementById('detailData');
    const closeButton = document.querySelector('.close-button');
    const fetchUserHistoryButton = document.getElementById('fetchUserHistory');
    const userIDInput = document.getElementById('userID');

    // Dummy Data with User ID
    let dummyData = [];
    for (let i = 1; i <= 60; i++) {
        dummyData.push({
            index: i, // Keep index consistent and starting from 1
            userID: Math.floor(Math.random() * 100) + 1,
            reservationID: `RES${i}`,
            checkInDate: `2024-08-${Math.floor(Math.random() * 30) + 1}`,
            checkOutDate: `2024-08-${Math.floor(Math.random() * 30) + 1}`,
            roomNumber: Math.floor(Math.random() * 100) + 1,
            billAmount: (Math.random() * 500).toFixed(2),
            bookingDate: `2024-07-${Math.floor(Math.random() * 30) + 1}`
        });
    }

    let currentPage = 1;
    let itemsPerPage = parseInt(itemsPerPageSelect.value);

    function renderTable(data, page = 1) {
        const start = (page - 1) * itemsPerPage;
        const end = start + itemsPerPage;
        const paginatedData = data.slice(start, end);

        tableBody.innerHTML = '';
        paginatedData.forEach((item, index) => {
            const row = document.createElement('tr');
            row.innerHTML = `
                <td>${start + index + 1}</td> <!-- Display index consistently -->
                <td>${item.userID}</td>
                <td>${item.reservationID}</td>
                <td>${item.checkInDate}</td>
                <td>${item.checkOutDate}</td>
                <td>${item.roomNumber}</td>
                <td>${item.billAmount}</td>
                <td>${item.bookingDate}</td>
                <td><button class="view-button">View</button></td>
            `;
            const button = row.querySelector('.view-button');
            button.addEventListener('click', () => showDetail(item));
            tableBody.appendChild(row);
        });

        updatePagination(data.length);
    }

    function updatePagination(totalItems) {
        const totalPages = Math.ceil(totalItems / itemsPerPage);
        const pageNumbers = document.getElementById('pageNumbers');
        pageNumbers.innerHTML = '';

        for (let i = 1; i <= totalPages; i++) {
            const button = document.createElement('button');
            button.textContent = i;
            button.className = 'page-button';
            if (i === currentPage) button.classList.add('active');
            button.addEventListener('click', () => {
                currentPage = i;
                renderTable(dummyData, currentPage);
            });
            pageNumbers.appendChild(button);
        }

        prevButton.disabled = currentPage === 1;
        nextButton.disabled = currentPage === totalPages;
    }

    function showDetail(item) {
        detailData.innerHTML = `
            <h3>Details for Reservation ${item.reservationID}</h3>
            <p><strong>User ID:</strong> ${item.userID}</p>
            <p><strong>Reservation ID:</strong> ${item.reservationID}</p>
            <p><strong>Check-in Date:</strong> ${item.checkInDate}</p>
            <p><strong>Check-out Date:</strong> ${item.checkOutDate}</p>
            <p><strong>Room Number:</strong> ${item.roomNumber}</p>
            <p><strong>Bill Amount:</strong> $${item.billAmount}</p>
            <p><strong>Booking Date:</strong> ${item.bookingDate}</p>
        `;
        detailView.classList.remove('hidden');
        detailView.style.animation = 'fadeIn 0.5s';
    }

    closeButton.addEventListener('click', () => {
        detailView.style.animation = 'fadeOut 0.5s';
        setTimeout(() => {
            detailView.classList.add('hidden');
        }, 500); // Match the duration of the fade-out animation
    });

    fetchUserHistoryButton.addEventListener('click', () => {
        const userID = userIDInput.value.trim();
        if (userID) {
            const filteredData = dummyData.filter(item => item.userID === parseInt(userID));
            renderTable(filteredData, 1);
        } else {
            renderTable(dummyData, 1); // Show all data if no userID is entered
        }
    });

    prevButton.addEventListener('click', () => {
        if (currentPage > 1) {
            currentPage--;
            renderTable(dummyData, currentPage);
        }
    });

    nextButton.addEventListener('click', () => {
        const totalPages = Math.ceil(dummyData.length / itemsPerPage);
        if (currentPage < totalPages) {
            currentPage++;
            renderTable(dummyData, currentPage);
        }
    });

    itemsPerPageSelect.addEventListener('change', () => {
        itemsPerPage = parseInt(itemsPerPageSelect.value);
        renderTable(dummyData, 1); // Render first page of new items per page setting
    });

    // Initial Render
    renderTable(dummyData, currentPage);
    const menuToggle = document.getElementById('menuToggle');
    const menu = document.getElementById('menu');

    menuToggle.addEventListener('click', function() {
        menu.classList.toggle('active');
        menuToggle.classList.toggle('active');
    });
});