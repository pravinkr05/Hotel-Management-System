package com.Controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.Model.Reservation;
import com.Operation.HMSOperation;

@WebServlet("/checkoutServelet")
public class checkoutServelet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String resId = request.getParameter("resId");
		if(resId!=null) {
			
		int rid= Integer.parseInt(resId);
		List<Reservation> ll = HMSOperation.fetchSpecificCustomerBill(rid);
	
		
		if(!ll.isEmpty()) {
		    request.setAttribute("billList", ll.get(0));
		    request.getSession().setAttribute("resid", ll.get(0).getResId());
			request.getSession().setAttribute("totalbill",ll.get(0).getBill()+ll.get(0).getFoodBill()+ll.get(0).getServiceCharge()+ll.get(0).getAdditionalCharge());
		    RequestDispatcher dispatcher = request.getRequestDispatcher("CheckoutView/checkout.jsp");
			dispatcher.forward(request,  response);
		    return;
		}else {
			response.getWriter().println("No list is available");
			return;
		}
	}
	else {
		response.getWriter().println("No list is available");
		return;
	}
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		doGet(request, response);
	}

}
