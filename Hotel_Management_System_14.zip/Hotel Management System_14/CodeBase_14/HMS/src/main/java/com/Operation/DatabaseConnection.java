package com.Operation;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DatabaseConnection{

    private static Connection connection = null;

    // Private constructor to prevent instantiation
    private DatabaseConnection() { }

    // Method to get the single connection instance
    public static Connection getConnection() {
    
            try {

				Class.forName("org.apache.derby.jdbc.EmbeddedDriver");
				connection = DriverManager.getConnection("jdbc:derby:D:\\Users\\2725297\\MyDB;create=true");
	        
	          	if (connection != null) {
	                  
	              	System.out.println(" Database Connected");
	              }else{
	              	System.out.println("ERROR! Database not Connected");

	              }
            } catch (ClassNotFoundException | SQLException e) {
                e.printStackTrace();
            }
        
        return connection;
    }
}