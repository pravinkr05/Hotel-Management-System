

const bookings = [
    { reservationId: 'RES123', checkInDate: '2024-09-01', checkOutDate: '2024-09-05', roomNumber: 101 },
    { reservationId: 'RES124', checkInDate: '2024-09-10', checkOutDate: '2024-09-15', roomNumber: 102 },
    { reservationId: 'RES125', checkInDate: '2024-09-20', checkOutDate: '2024-09-25', roomNumber: 103 }
];

document.addEventListener('DOMContentLoaded', function() {
    const bookingsList = document.getElementById('bookingsList');



    function renderBookings() {
        bookingsList.innerHTML = ''; // Clear existing content
        bookings.forEach(booking => {
            const bookingDiv = document.createElement('div');
            bookingDiv.className = 'bookingItem';
            bookingDiv.innerHTML = `
                <p><strong>Reservation ID:</strong> ${booking.reservationId}</p>
                <p><strong>Check-in Date:</strong> ${booking.checkInDate}</p>
                <p><strong>Check-out Date:</strong> ${booking.checkOutDate}</p>
                <p><strong>Room Number:</strong> ${booking.roomNumber}</p>
                <button onClick="location.href='../check out user/user.html'">Checkout</button>
            `;
            bookingsList.appendChild(bookingDiv);
        });
    }

    renderBookings();
});
