
        document.getElementById('username').textContent = 'Guest';

        function logout() {
            alert("You have been logged out.");
            window.location.href="../Login/login.html";
        }

        function submitFeedback() {
            const feedback = document.getElementById('feedback').value;
            if (feedback.trim() === "") {
                alert("Please enter your feedback before submitting.");
            } else {
                alert("Thank you for your feedback!");
                document.getElementById('feedback').value = ""; 
            }
        }