package com.Controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.Model.Reservation;
import com.Operation.HMSOperation;


@WebServlet("/adminReservationServelet")
public class adminReservationServelet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
 
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub

	
	   
	        List<Reservation> reservations =  HMSOperation.getAllReservations();
	        

	        request.setAttribute("reservations", reservations);
	        
	    
	        RequestDispatcher dispatcher = request.getRequestDispatcher("Reservation/adminReservation.jsp");
	        dispatcher.forward(request, response);
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
        String reservationId = request.getParameter("reservationId");
        String status = request.getParameter("status");
        
        if (reservationId != null && status != null) {
       
            HMSOperation.updateReservationStatus(Integer.parseInt(reservationId), status);
            doGet(request,response);
        }else {
        	response.getWriter().println("Invalid Reservation");
        }
          

	}
	
 }

