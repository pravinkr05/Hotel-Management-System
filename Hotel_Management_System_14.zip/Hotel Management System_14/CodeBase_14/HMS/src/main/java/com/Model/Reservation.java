package com.Model;

public class Reservation {
	int rid;
	String userId;
	String checkIn; 
	String checkOut; 
	String roomP; 
	String name; 
	String contact;
	String status;
	String payment_status;
	int roomno;
	
	int totalBill,foodBill,serviceCharge,additionalCharge;
	

	public int getRoomno() {
		return roomno;
	}
	public void setRoomno(int roomno) {
		this.roomno = roomno;
	}
	public Reservation() {}
	public Reservation(int rid,String userId,String checkIn, String checkOut, 
			String roomP, String name, String contact,String status,String pstatus,int bill
			,int fb,int sc,int ac, int rn) {
	    this.rid=rid;
		this.checkIn = checkIn;
		this.checkOut = checkOut;
		this.roomP = roomP;
		this.name = name;
		this.contact = contact;
		this.userId=userId;
		this.status=status;	
	    this.payment_status=pstatus;
	    this.totalBill = bill;
	    this.foodBill = fb;
	    this.serviceCharge = sc;
	    this.additionalCharge = ac;
	    this.roomno=rn;
	}
	public Reservation(int rid,String userId,String checkIn, String checkOut, 
			String roomP, String name, String contact,String status,String pstatus) {
	    this.rid=rid;
		this.checkIn = checkIn;
		this.checkOut = checkOut;
		this.roomP = roomP;
		this.name = name;
		this.contact = contact;
		this.userId=userId;
		this.status=status;	
	    this.payment_status=pstatus;
	   
	}
	
	
	public int getTotalBill() {
		return totalBill;
	}
	public void setTotalBill(int totalBill) {
		this.totalBill = totalBill;
	}
	public int getFoodBill() {
		return foodBill;
	}
	public void setFoodBill(int foodBill) {
		this.foodBill = foodBill;
	}
	public int getServiceCharge() {
		return serviceCharge;
	}
	public void setServiceCharge(int serviceCharge) {
		this.serviceCharge = serviceCharge;
	}
	public int getAdditionalCharge() {
		return additionalCharge;
	}
	public void setAdditionalCharge(int additionalCharge) {
		this.additionalCharge = additionalCharge;
	}
	public int getRid() {
		return rid;
	}


	public void setRid(int rid) {
		this.rid = rid;
	}


	public String getStatus() {
		return status;
	}


	public void setStatus(String status) {
		this.status = status;
	}


	public String getPayment() {
		return payment_status;
	}


	public void setPayment(String payment) {
		this.payment_status = payment;
	}

	
	public int getBill() {
		return totalBill;
	}
	public void setBill(int bill) {
		this.totalBill = bill;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public int getResId() {
		return rid;
	}
	public void setResId(int rId) {
		this.rid = rId;
	}
	public String getCheckIn() {
		return checkIn;
	}
	public void setCheckIn(String checkIn) {
		this.checkIn = checkIn;
	}
	public String getCheckOut() {
		return checkOut;
	}
	public void setCheckOut(String checkOut) {
		this.checkOut = checkOut;
	}
	public String getRoomP() {
		return roomP;
	}
	public void setRoomP(String roomP) {
		this.roomP = roomP;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getContact() {
		return contact;
	}
	public void setContact(String contact) {
		this.contact = contact;
	} 
	
	
}
