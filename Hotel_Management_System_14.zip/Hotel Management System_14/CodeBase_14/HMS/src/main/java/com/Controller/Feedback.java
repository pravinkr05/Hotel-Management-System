package com.Controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/Feedback")
public class Feedback extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	// Create a shared list to store feedback and complaints
	private List<List<String>> feedbackList = new ArrayList<>();

 
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Retrieve data from the form
        String customerId = request.getParameter("customerId");
        String contact = request.getParameter("contactNumber");
        String feedback = request.getParameter("feedback");
        String complaint = request.getParameter("complaint");

        // Create a list for each entry
        List<String> feedbackEntry = new ArrayList<>();
        feedbackEntry.add(customerId);
        feedbackEntry.add(contact);
        feedbackEntry.add(feedback);
        feedbackEntry.add(complaint);

        // Add the entry to the feedback list
        feedbackList.add(feedbackEntry);

        // Store the list in the application context so it's accessible across servlets
        ServletContext context = getServletContext();
        context.setAttribute("allFeedback", feedbackList);

        // Redirect back to the homepage or confirmation page
        RequestDispatcher rd = request.getRequestDispatcher("/WEB-INF/views/homepage.jsp");
        rd.forward(request, response);
	}
}

