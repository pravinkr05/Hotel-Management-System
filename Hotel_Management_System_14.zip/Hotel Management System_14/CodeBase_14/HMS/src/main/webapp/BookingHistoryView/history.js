// Generate 60 dummy items
const dummyData = Array.from({ length: 60 }, (_, i) => {
    const checkInDay = 20 + (i % 10);  // Limit day to 20-29 range
    const checkOutDay = 25 + (i % 10); // Limit day to 25-29 range
    const bookingDay = 15 + (i % 10);  // Limit day to 15-24 range
  
    return {
      reservationID: (12345 + i).toString(),
      checkInDate: `2024-08-${checkInDay.toString().padStart(2, '0')}`, // Format day with leading zero
      checkOutDate: `2024-08-${checkOutDay.toString().padStart(2, '0')}`, // Format day with leading zero
      roomNumber: (101 + (i % 10)).toString(),
      billAmount: `$${(500 + i * 5).toFixed(2)}`, // Ensure consistent price formatting
      bookingDate: `2024-07-${bookingDay.toString().padStart(2, '0')}` // Format day with leading zero
    };
  });
    

// Set dummy user info in localStorage
if (!localStorage.getItem('user')) {
    localStorage.setItem('user', JSON.stringify({ name: 'John Doe' }));
}

// Retrieve user info from localStorage
const user = JSON.parse(localStorage.getItem('user'));

// Handle role and booking history
const role = localStorage.getItem('role') || 'customer';
const bookingHistory =  dummyData || JSON.parse(localStorage.getItem('bookingHistory'));

window.onload = function() {
    const pageTitle = document.getElementById('pageTitle');
    const historyTable = document.getElementById('historyTable').getElementsByTagName('tbody')[0];
    const adminSection = document.getElementById('adminSection');
    const searchBar = document.getElementById('searchBar');
    const itemsPerPageSelect = document.getElementById('itemsPerPage');
    const pageNumbersDiv = document.getElementById('pageNumbers');
    const greeting = document.getElementById('greeting');
    const prevButton = document.getElementById('prevButton');
    const nextButton = document.getElementById('nextButton');

    // Set greeting
    greeting.textContent = `Hi, ${user.name || 'Login'}`;

    // Set page title and admin section visibility
    if (role === 'customer') {
        pageTitle.textContent = "Your Booking History";
        adminSection.classList.add('hidden');
    } else if (role === 'admin') {
        pageTitle.textContent = "Admin - View User Booking History";
        adminSection.classList.remove('hidden');
        document.getElementById('fetchUserHistory').addEventListener('click', function() {
            // Fetch user history based on UserID (Dummy data here)
            const userID = document.getElementById('userID').value;
            if (userID) {
                // Replace with actual fetch logic
                populateTable(bookingHistory);
            }
        });
    }

    let itemsPerPage = parseInt(itemsPerPageSelect.value);
    let currentPage = 1;
    let filteredData = bookingHistory;

    function renderPagination() {
        const totalPages = Math.ceil(filteredData.length / itemsPerPage);
        pageNumbersDiv.innerHTML = '';

        if (currentPage > 1) {
            prevButton.style.display = 'inline';
        } else {
            prevButton.style.display = 'none';
        }

        if (currentPage < totalPages) {
            nextButton.style.display = 'inline';
        } else {
            nextButton.style.display = 'none';
        }

        for (let i = 1; i <= totalPages; i++) {
            const pageButton = document.createElement('button');
            pageButton.textContent = i;
            pageButton.className = 'page-button';
            if (i === currentPage) {
                pageButton.classList.add('active');
            }
            pageButton.addEventListener('click', () => {
                currentPage = i;
                renderTable();
            });
            pageNumbersDiv.appendChild(pageButton);
        }
    }

    function renderTable() {
        historyTable.innerHTML = ''; // Clear existing data
        const startIndex = (currentPage - 1) * itemsPerPage;
        const endIndex = startIndex + itemsPerPage;
        const pageData = filteredData.slice(startIndex, endIndex);
    
        pageData.forEach((booking, index) => {
            let row = historyTable.insertRow();
            row.innerHTML = `
                <td>${startIndex + index + 1}</td> <!-- Index number -->
                <td>${booking.reservationID}</td>
                <td>${booking.checkInDate}</td>
                <td>${booking.checkOutDate}</td>
                <td>${booking.roomNumber}</td>
                <td>${booking.billAmount}</td>
                <td>${booking.bookingDate}</td>
            `;
        });
    
        renderPagination();
    }    

    function filterTable() {
        const query = searchBar.value.toLowerCase();
        filteredData = bookingHistory.filter((booking) =>
            Object.values(booking).some(value =>
                value.toLowerCase().includes(query)
            )
        );
        currentPage = 1;
        renderTable();
    }

    searchBar.addEventListener('input', filterTable);
    itemsPerPageSelect.addEventListener('change', () => {
        itemsPerPage = parseInt(itemsPerPageSelect.value);
        renderTable();
    });

    // Previous and Next button handlers
    prevButton.addEventListener('click', () => {
        if (currentPage > 1) {
            currentPage--;
            renderTable();
        }
    });

    nextButton.addEventListener('click', () => {
        const totalPages = Math.ceil(filteredData.length / itemsPerPage);
        if (currentPage < totalPages) {
            currentPage++;
            renderTable();
        }
    });

    // Initial render
    renderTable();

    // Toggle menu functionality
    const menuToggle = document.getElementById('menuToggle');
    const menu = document.getElementById('menu');

    menuToggle.addEventListener('click', function() {
        menu.classList.toggle('active');
        menuToggle.classList.toggle('active');
    });
}