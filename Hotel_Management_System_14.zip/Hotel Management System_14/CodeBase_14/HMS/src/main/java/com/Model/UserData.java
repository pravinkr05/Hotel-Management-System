package com.Model;

public class UserData {
	String UserID;
	String Username;
	String Phno;

	String Email;
	String Address;
	
	String Pswd;

	public UserData(String username,String phno,String email,String address,String userId, String pswd) {

		UserID = userId;
		Username = username;
		Phno = phno;
		Email = email;
		Address = address;
		Pswd = pswd;
	}

	public String getUserID() {
		return UserID;
	}

	public void setUserID(String userID) {
		UserID = userID;
	}

	public String getUsername() {
		return Username;
	}

	public void setUsername(String username) {
		Username = username;
	}

	public String getPhno() {
		return Phno;
	}

	public void setPhno(String phno) {
		Phno = phno;
	}

	public String getEmail() {
		return Email;
	}

	public void setEmail(String email) {
		Email = email;
	}

	public String getAddress() {
		return Address;
	}

	public void setAddress(String address) {
		Address = address;
	}

	public String getPswd() {
		return Pswd;
	}

	public void setPswd(String pswd) {
		Pswd = pswd;
	}
	
	
	
	
	
}
